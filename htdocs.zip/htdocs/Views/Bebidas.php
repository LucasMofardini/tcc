<!DOCTYPE html>

<?php
$tipo = 3;

include_once('../Controller/config.php');
include_once('../Controller/BebidasPHP.php');

?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

  </body>
</html>
