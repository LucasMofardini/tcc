<!DOCTYPE html>

<?php
$tipo = 2;
include_once('../Controller/config.php');
include_once('../Controller/PizzasDocesPHP.php');


?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

  </body>
</html>
